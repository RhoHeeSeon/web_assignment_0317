<template>
<div>
    <span>{{num}}</span>
    <button @click="plus">+</button>
    <button @click="minus">-</button>
</div>

</template>

<script>
import { mapState, mapMutations } from 'vuex'

export default{
    name: 'PlusMinus',
    computed:{
        ...mapState(['num']),
    },
    methods:{
        ...mapMutations(['plus', 'minus'])
    }
}
</script>

<style>
div > button {
    margin: 0px 10px;
}
</style>