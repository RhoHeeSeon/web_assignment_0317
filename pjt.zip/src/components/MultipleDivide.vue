<template>
<div>
    <span>{{num}}</span>
    <button @click="multiple">*</button>
    <button @click="divide">/</button>
</div>

</template>

<script>
import { mapState, mapMutations } from 'vuex'

export default{
    name: 'MultipleDivide',
    computed:{
        ...mapState(['num']),
    },
    methods:{
        ...mapMutations(['multiple', 'divide'])
    }
}
</script>

<style>
div > button {
    margin: 0px 10px;
}
</style>
