<template>
    <MultipleDivide/>
</template>

<script>
import MultipleDivide from '../components/MultipleDivide.vue'


export default{
    name: 'SSAFY',
    components: {
        MultipleDivide
    },

}
</script>
