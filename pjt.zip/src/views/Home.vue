<template>
  <div class="home">
    <img alt="Vue logo" src="../assets/logo.png">
    <PlusMinus/>
  </div>
</template>

<script>
import PlusMinus from '../components/PlusMinus.vue'

export default {
  name: 'Home',
  components: {
    PlusMinus
  }
}
</script>
